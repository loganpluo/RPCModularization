package com.github.rpc.modularization.plugin

class ClassInfo{

    int version;
    int access;
    String name;
    String signature;
    String superName;
    String[] interfaces

    String annotationDesc

    String destFilePath

}