package com.github.rpc.modularization.plugin

class LogUtil{

    static void d(String TAG, String msg){
        println(" $TAG : $msg")
    }

    static void i(String TAG, String msg){
        println(" $TAG : $msg")
    }

}