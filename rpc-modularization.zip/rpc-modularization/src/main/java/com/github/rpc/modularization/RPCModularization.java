package com.github.rpc.modularization;

import android.content.Context;

public interface RPCModularization {

    void initModule(Context context);
    void initModuleService();

}
