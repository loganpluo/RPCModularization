package com.github.rpc.modularization;

import android.content.Context;

public interface RPCModule {
    void onInit(Context context);
}
